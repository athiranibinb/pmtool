import React, { useEffect, useState } from "react";
import {
  Button,
  Input,
  Popconfirm,
  TableProps,
  Space,
  Table,
  Tag,
  Radio,
  RadioChangeEvent,
} from "antd";
import type { ColumnsType } from "antd/es/table";
import AdminLayout from "../component/AdminLayout";
import axios from "../API/axios";
import { SyncOutlined } from "@ant-design/icons";
import { SorterResult } from "antd/es/table/interface";
const { Search } = Input;
const token = localStorage.getItem("token");
const sanitizedToken = token?.replace(/^"(.*)"$/, "$1");

const headers = {
  Authorization: `Bearer ${sanitizedToken}`,
};
interface DataType {
  id: number;
  projectName: string;
  projectId: number;
  isActive: boolean;
}

const ManageProject: React.FC = () => {
  const [sortedInfo, setSortedInfo] = useState<SorterResult<DataType>>({});

  const [data, setData] = useState<DataType[]>([]);
  const [searchText, setSearchText] = useState("");
  const [filteredData, setFilteredData] = useState<DataType[]>([]);
  const [value3, setValue3] = useState(1);
  const [projectType, setProjectType] = useState(1);
  //table column definitions
  const columns: ColumnsType<any> = [
    {
      title: "Sl No",
      dataIndex: "id",
      key: "id",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Project Name",
      dataIndex: "projectName",
      key: "projectName",
      sorter: (a, b) => a.projectName - b.projectName,
      // sortOrder: sortedInfo.columnKey === 'name' ? sortedInfo.order : null,
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Status",
      dataIndex: "isActive",
      key: "isActive",
      render: (text: boolean) => <a>{text ? "Active" : "Inactive"}</a>,
    },
    {
      title: "Action",
      key: "action",
      render: (text, record) =>
        record.isActive ? (
          <Popconfirm
            title="Are you sure you want to disable the project?"
            onConfirm={() => handleDisabled(record)}
          >
            <a>Disable</a>
          </Popconfirm>
        ) : (
          <Popconfirm
            title="Are you sure you want to enable the project?"
            onConfirm={() => handleEnable(record)}
          >
            <a>Enable</a>
          </Popconfirm>
        ),
    },
  ];
  //disabling project
  const handleDisabled = async (key: any) => {
    try {
      const response = await axios.put(
        `/Resources/EnableOrDisableProject?projectId=${key.projectId}&isDisable=true`,
        null,
        {
          // Include data to be sent with the DELETE request
          headers: headers, // Include custom headers if needed
        }
      );
      console.log("success disabling");
    } catch (error) {
      console.log("error disabling");
    }
  };
  //enabling project
  const handleEnable = async (key: any) => {
    try {
      const response = await axios.put(
        `/Resources/EnableOrDisableProject?projectId=${key.projectId}&isDisable=false`,
        null,
        {
          // Include data to be sent with the DELETE request
          headers: headers, // Include custom headers if needed
        }
      );
      console.log("success enabling");
    } catch (error) {
      console.log("error disabling");
    }
  };

  const handleChange: TableProps<DataType>["onChange"] = (
    pagination,
    filters,
    sorter
  ) => {
    setSortedInfo(sorter as SorterResult<DataType>);
  };

  //sync project from pms
  const syncProjectHandler = async () => {
    try {
      const response = await axios.get("Resources/SyncProject", {
        // Pass data parameters in the URL query string
        headers: headers, // Set headers in the request configuration
      });
      fetchData();
    } catch (error) {
      console.log("error syncing the projects");
    }
  };

  const fetchData = async () => {
    console.log(projectType);
    try {
      const response = await axios.get(
        `Resources/GetProjects?status=${projectType}`,
        {
          // Pass data parameters in the URL query string
          headers: headers, // Set headers in the request configuration
        }
      );
      const dataWithSiNo = response.data.map((project: any, index: number) => ({
        ...project,
        id: index + 1, // Adding 1 to make it 1-based index
        key: project.projectId,
      }));
      setData(dataWithSiNo);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const filterData = (searchText: string) => {
    if (!searchText) {
      setFilteredData([]);
    } else {
      const filtered = data.filter((item) =>
        item.projectName.toLowerCase().includes(searchText.toLowerCase())
      );
      setFilteredData(filtered);
    }
  };

  const handleSearch = (value: string) => {
    setSearchText(value);
    filterData(value);
  };
  const options = [
    { label: "All", value: 1 },
    { label: "Active Projects", value: 2 },
    { label: "Inactive Projects", value: 3 },
  ];
  const changeProjectTypeHandler = ({
    target: { value },
  }: RadioChangeEvent) => {
    setProjectType(value);
    fetchData();
  };
  return (
    <AdminLayout>
      <h1>Manage Project</h1>
      <Button
        icon={<SyncOutlined />}
        type="primary"
        onClick={syncProjectHandler}
      >
        Sync Now
      </Button>
      <Radio.Group
        options={options}
        onChange={changeProjectTypeHandler}
        value={value3}
        optionType="button"
      />
      <Search
        placeholder="Search by project name"
        allowClear
        onSearch={handleSearch}
        style={{ width: 200 }}
      />
      <Table
        columns={columns}
        onChange={handleChange}
        dataSource={searchText ? filteredData : data}
      />
    </AdminLayout>
  );
};

export default ManageProject;
