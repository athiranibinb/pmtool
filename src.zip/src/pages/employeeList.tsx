import EmployeeListTable from "../component/EmployeeListTable";

const EmployeeList = () => {
    return (
        <div><h1>Employee List</h1>

            <EmployeeListTable/>
        </div>
    )
}
export default EmployeeList;