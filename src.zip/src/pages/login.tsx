import LoginForm from "../component/LoginForm";

const Login = () => {
    return <div><LoginForm/></div>
}
export default Login;