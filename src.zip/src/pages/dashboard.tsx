import AdminLayout from "../component/AdminLayout";
import EmployeeList from "./employeeList";

const Dashboard: React.FC = () => {
    return (
      <AdminLayout>
        <EmployeeList/>

      </AdminLayout>

    );
  };
  
  export default Dashboard;