import './Navbar.scss'
// import SubjectIcon from '@mui/icons-material/Subject';
// import QuizIcon from '@mui/icons-material/Quiz';
import avtar from '../../avtar.png'
import { useNavigate } from 'react-router-dom';
// import { useAuth } from '../auth';
import { LogoutOutlined } from '@ant-design/icons';
const Navbar = () => {
    const navigate = useNavigate();
    // const auth = useAuth();
    function onLogout() {
        localStorage.clear();
        // auth.logout()
        navigate(`/`);

    }
    return (
        <div className='navbar'> 
            <div className='wrapper'>
                <div className='search'>
                <input type="text" placeholder='Search'/>
                </div>
                <div className='items'>
               
                <div className='item' onClick={onLogout}>
                    <LogoutOutlined/>
                    Logout
                </div>
                {/* <div className='item'>
                    <img src={avtar} alt= "" className="avtar" />
                </div> */}
                </div>
            </div>
        </div>
    )
}
 export default Navbar