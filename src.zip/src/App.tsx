import React from 'react';
import { Route } from 'react-router';
import { Routes,BrowserRouter } from 'react-router-dom';
import { isAuthenticated } from './API/RequireAuth';
// import { RequireAuth } from './API/RequireAuth';
import './App.css';
import Dashboard from './pages/dashboard';
import EmployeeList from './pages/employeeList';
import Login from './pages/login';
import ManageProject from './pages/manageProjects';

function App() {
  return (
    <div className="App">
            <BrowserRouter>

    <Routes>
      
      <Route path='/'>
        <Route index element={<Login/>}/>
        <Route path='login' element={<Login/>}/>
      
        <Route
            path="/dashboard"   
            element={isAuthenticated() ? <Dashboard /> : <Login/>}
           
          />
          <Route
            path="/dashboard/employee-list"   
            element={isAuthenticated() ? <EmployeeList /> : <Login/>}
           
          />
       <Route
            path="/manage-projecct"   
            element={isAuthenticated() ? <ManageProject /> : <Login/>}
           
          />
      </Route>
    </Routes>
    </BrowserRouter>
    </div>
  );
}

export default App;
