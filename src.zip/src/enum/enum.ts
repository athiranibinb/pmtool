export enum projectTypes {
    ALL = 1,
    ACTIVE = 2,
    INACTIVE = 3
}