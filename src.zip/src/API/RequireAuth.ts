
export const getToken = () => {
  // Retrieve the token from local storage
  return localStorage.getItem('token');
};

export const isAuthenticated = () => {
  // Check if the user is authenticated
  const token = getToken();
  return token !== null;
};

export const onLogout = () => {
  localStorage.removeItem('token')
}