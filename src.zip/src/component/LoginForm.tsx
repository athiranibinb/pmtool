import React from "react";
import { Button, Form, Input, Space, message } from "antd";
import "./LoginForm.css";
import { FormInstance } from "antd/es/form";
import axios from "../API/axios";
import { useNavigate } from "react-router-dom";

const onFinishFailed = async (errorInfo: any) => {};

type FormData = {
  username?: string;
  password?: string;
};

const LoginForm: React.FC = () => {
  const navigate = useNavigate();

  const [form] = Form.useForm();
  const [messageApi, contextHolder] = message.useMessage();
  const onFinish = async (values: any) => {
    try {
      const response = await axios.post(
        "Account/Login",
        JSON.stringify(values),
        {
          headers: { "Content-type": "application/json" },
          withCredentials: true,
        }
      );
      localStorage.setItem("token", response.data.token);
      navigate(`/dashboard`, { replace: true });
    } catch (error) {
      messageApi.error("Enter valid username and password");
    }
  };
  return (
    <>
      {contextHolder}

      <Form
        form={form}
        name="basic"
        labelCol={{ span: 8 }}
        wrapperCol={{ span: 16 }}
        style={{ maxWidth: 600 }}
        initialValues={{ remember: true }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
      >
        <Form.Item<FormData>
          label="EmailID"
          name="username"
          rules={[{ required: true, message: "Please Enter EmailID" }]}
        >
          <Input />
        </Form.Item>

        <Form.Item<FormData>
          label="Password"
          name="password"
          rules={[{ required: true, message: "Please input Password" }]}
        >
          <Input.Password />
        </Form.Item>

        <a className="login-form-forgot" href="">
          Forgot password
        </a>
        <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
          <Space>
            <SubmitButton form={form} />
          </Space>
          
        </Form.Item>
      </Form>
    </>
  );
};

//for submit button
const SubmitButton = ({ form }: { form: FormInstance }) => {
  const [submittable, setSubmittable] = React.useState(false);

  // Watch all values
  const values = Form.useWatch([], form);

  React.useEffect(() => {
    form.validateFields({ validateOnly: true }).then(
      () => {
        setSubmittable(true);
      },
      () => {
        setSubmittable(false);
      }
    );
  }, [values]);

  return (
    <Button type="primary" htmlType="submit" disabled={!submittable}>
      Submit
    </Button>
  );
};

export default LoginForm;
