import type { ColumnsType } from "antd/es/table";
import { Button, Input, Popconfirm, TableProps, Space, Table, Tag } from "antd";
import { useEffect, useState } from "react";
import axios from "../API/axios";
const token = localStorage.getItem("token");
const sanitizedToken = token?.replace(/^"(.*)"$/, "$1");
const { Search } = Input;

const headers = {
  Authorization: `Bearer ${sanitizedToken}`,
};
interface DataType {
  employeeId: string;
  employeeName: string;
  designation: string;
  totalExp: string;
  vofoxExp: string;
  previousExp: string;
  teamLead: string;
  status: string;
  projectIdList: [];
  projects: string;
  techSkillIdList: [];
  techSkills: string;
  comments: string;
}
interface DataType {
  id: number;
  projectName: string;
  projectId: number;
  isActive: boolean;
}
const EmployeeListTable = () => {
  const [searchText, setSearchText] = useState("");
  const [filteredData, setFilteredData] = useState<DataType[]>([]);

  const [data, setData] = useState<DataType[]>([]);

  const handleSearch = (value: string) => {
    setSearchText(value);
    filterData(value);
  };
  const filterData = (searchText: string) => {
    if (!searchText) {
      setFilteredData([]);
    } else {
      const filtered = data.filter((item: any) =>
        item.employeeName.toLowerCase().includes(searchText.toLowerCase())
      );
      setFilteredData(filtered);
    }
  };

  const columns: ColumnsType<any> = [
    {
      title: "Sl No",
      dataIndex: "id",
      key: "id",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Employee Name",
      dataIndex: "employeeName",
      key: "employeeName",
      sorter: (a, b) => a.projectName - b.projectName,
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Designation",
      dataIndex: "designation",
      key: "designation",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Total Exp",
      dataIndex: "totalExp",
      key: "totalExp",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Vofox Exp",
      dataIndex: "vofoxExp",
      key: "vofoxExp",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Prev Exp",
      dataIndex: "previousExp",
      key: "previousExp",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "TL",
      dataIndex: "teamLead",
      key: "teamLead",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Project",
      dataIndex: "projects",
      key: "projects",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Technologies",
      dataIndex: "techSkills",
      key: "techSkills",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Comments",
      dataIndex: "comments",
      key: "comments",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Action",
      key: "action",
      render: (text, record) => <a>Edit</a>,
    },
  ];

  useEffect(() => {
    fetchData();
  }, []); // Empty dependency array means this effect runs once when the component mounts

  const fetchData = async () => {
    const data = {
      noOfRecordsPerPage: 15,
      pageNumber: 1,
    };
    try {
      const response = await axios.post("Resources/GetEmployeeList", data, {
        headers: headers,
      });
      const dataWithSiNo = response.data.map((project: any, index: number) => ({
        ...project,
        id: index + 1, // Adding 1 to make it 1-based index
        key: project.employeeId,
      }));
      setData(dataWithSiNo);
      debugger;
    } catch (error) {
      console.log("error fetching employee list", error);
    }
  };
  return (
    <div>
      <Search
        placeholder="Search by employee name"
        allowClear
        onSearch={handleSearch}
        style={{ width: 200 }}
      />
      <Table columns={columns} dataSource={searchText ? filteredData : data} />
    </div>
  );
};
export default EmployeeListTable;
