import { Layout, Menu,MenuProps,Breadcrumb,theme } from 'antd';
import React, { useState } from 'react';
import './AdminLayout.css'
// import { MenuProps } from 'antd/es/menu';
import {
    DesktopOutlined,
    FileOutlined,
    PieChartOutlined,
    TeamOutlined,
    UserOutlined,
    UnorderedListOutlined
  } from '@ant-design/icons';
import { onLogout } from '../API/RequireAuth';
import { Outlet, Route, Router, useNavigate} from 'react-router-dom';
import Dashboard from '../pages/dashboard';
import EmployeeList from '../pages/employeeList';
import ManageProject from '../pages/manageProjects';
const { Header, Sider, Content,Footer } = Layout;
type AdminLayoutProps = {
    children: React.ReactNode; // Define the children prop
  };
  type MenuItem = Required<MenuProps>['items'][number];
const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  const navigate = useNavigate();

    function getItem(
        label: React.ReactNode,
        key: React.Key,
        icon?: React.ReactNode,
        children?: MenuItem[],
      ): MenuItem {
        return {
          key,
          icon,
          children,
          label,
        } as MenuItem;
      }

      
    const items: MenuItem[] = [
        getItem('Employee List', '1', <UnorderedListOutlined />),
        getItem('Reports', 'sub1', <UserOutlined />, [
          // getItem('Employee', '3'),
          // getItem('Task', '4'),
          // getItem('Tl', '5'),
        ]),
        getItem('Manage Project', '5', <UserOutlined />, [
          // getItem('Employee', '3'),
          // getItem('Task', '4'),
          // getItem('Tl', '5'),
        ]),
      ];

      const [collapsed, setCollapsed] = useState(false);
      const {
        token: { colorBgContainer },
      } = theme.useToken();
    
      const onLogoutHandler = () => {
        onLogout();
        navigate(`/`,{replace:true});
      }
    return (
    
        <Layout style={{ minHeight: '100vh' }}>
      <Header style={{ display: 'flex', alignItems: 'center' }}>
        <p className='logout' onClick={onLogoutHandler}>Logout</p>
        <div className="demo-logo" />
      </Header>
      <Layout>
        <Sider width={200} collapsible collapsed={collapsed} onCollapse={(value) => setCollapsed(value)} style={{ background: colorBgContainer }}>
          <h3 className='headSider'>PM Tool</h3>
          <Menu
            mode="inline"
            defaultSelectedKeys={['1']}
            defaultOpenKeys={['sub1']}
            style={{ height: '100%', borderRight: 0 }}
            items={items}
          />
        </Sider>
        <Layout style={{ padding: '0 24px 24px' }}>
         
          <Content
            style={{
              padding: 24,
              margin: 0,
              minHeight: 280,
              background: colorBgContainer,
            }}
          >
             
           {children}
           <Outlet/>
          </Content> 
        </Layout>
      </Layout>
    </Layout>
 
    );
  };
  
  export default AdminLayout;